path = './Fe/bccFe_20kV_gnomon.tif'
#path = './Fe3C/fe3c_2.tif'
